package com.soundassistent.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class SoundPanelService : AccessibilityService() {
    companion object {
        var instance: SoundPanelService? = null
    }

    private lateinit var am: AudioManager
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val hideRun = Runnable { hide() }
    private var panel: LinearLayout? = null
    private var flexV: FlexVolumeView? = null
    private var title: TextView? = null
    private var muteBtn: TextView? = null
    private var expanded = false
    private var curStream = AudioManager.STREAM_MUSIC
    private val extraBars = HashMap<Int, SeekBar>()
    private val savedVol = HashMap<Int, Int>()

    private val streamIds = intArrayOf(
        AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING, AudioManager.STREAM_ALARM,
        AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_VOICE_CALL
    )
    private val streamNames = arrayOf("Medien", "Klingelton", "Alarm", "Benachrichtigung", "Anruf")

    private fun dp(x: Float) = (x * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        Fx.load(this)
        Fx.apply()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        hide()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onKeyEvent(ev: KeyEvent): Boolean {
        if (!Fx.panelOn) return false
        val code = ev.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false
        if (ev.action == KeyEvent.ACTION_DOWN) {
            val st = pickStream()
            try {
                am.adjustStreamVolume(
                    st,
                    if (code == KeyEvent.KEYCODE_VOLUME_UP) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                    0
                )
                if (st == AudioManager.STREAM_MUSIC) Fx.enforceLimit(this)
            } catch (e: SecurityException) {
            }
            if (Fx.haptic) buzz()
            show(st)
        }
        return true
    }

    private fun pickStream(): Int {
        val mode = am.mode
        if (mode == AudioManager.MODE_IN_CALL || mode == AudioManager.MODE_IN_COMMUNICATION) {
            return AudioManager.STREAM_VOICE_CALL
        }
        if (Fx.keyAuto && !am.isMusicActive) return AudioManager.STREAM_RING
        return AudioManager.STREAM_MUSIC
    }

    private fun buzz() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(12, 80))
        } catch (t: Throwable) {
        }
    }

    private fun pct(id: Int): Int {
        val m = am.getStreamMaxVolume(id)
        return if (m > 0) am.getStreamVolume(id) * 100 / m else 0
    }

    private fun setPct(id: Int, p: Int) {
        try {
            val max = am.getStreamMaxVolume(id)
            am.setStreamVolume(id, Math.round(p * max / 100f), 0)
            if (id == AudioManager.STREAM_MUSIC) Fx.enforceLimit(this)
        } catch (e: SecurityException) {
        }
    }

    private fun nameOf(id: Int): String {
        val i = streamIds.indexOf(id)
        return if (i >= 0) streamNames[i] else ""
    }

    private fun rearm() {
        handler.removeCallbacks(hideRun)
        handler.postDelayed(hideRun, Fx.timeout * 1000L)
    }

    fun show(st: Int) {
        curStream = st
        if (panel == null) createPanel()
        updatePanel()
        rearm()
    }

    private fun updatePanel() {
        val f = flexV
        if (f != null && !f.touching) f.value = pct(curStream)
        title?.text = nameOf(curStream)
        muteBtn?.text = if (am.getStreamVolume(curStream) == 0) "🔇" else "♪"
        for ((id, bar) in extraBars) {
            if (!bar.isPressed) bar.progress = pct(id)
        }
    }

    private fun toggleMute() {
        val cur = am.getStreamVolume(curStream)
        if (cur > 0) {
            savedVol[curStream] = cur
            try { am.setStreamVolume(curStream, 0, 0) } catch (e: SecurityException) {}
        } else {
            val back = savedVol[curStream] ?: (am.getStreamMaxVolume(curStream) / 2)
            try { am.setStreamVolume(curStream, back, 0) } catch (e: SecurityException) {}
        }
        updatePanel()
        rearm()
    }

    private fun createPanel() {
        val s = when (Fx.panelSize) { 0 -> 0.8f; 2 -> 1.3f; else -> 1f }
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        val pad = dp(12f * s)
        box.setPadding(pad, pad, pad, pad)
        val bg = GradientDrawable()
        bg.setColor(Color.argb(Fx.opacity * 255 / 100, 24, 24, 28))
        bg.cornerRadius = dp(32f * s).toFloat()
        box.background = bg

        val dots = TextView(this)
        dots.text = "•••"
        dots.setTextColor(Color.WHITE)
        dots.textSize = 18f
        dots.setPadding(pad, 0, pad, dp(4f))

        val name = TextView(this)
        name.setTextColor(0xCCFFFFFF.toInt())
        name.textSize = 12f
        name.gravity = Gravity.CENTER

        val fv = FlexVolumeView(this)
        fv.knob = Fx.knob
        fv.lighting = Fx.lighting
        fv.texture = Fx.texture
        fv.barFrac = 0.9f
        fv.layoutParams = if (Fx.knob) LinearLayout.LayoutParams(dp(150f * s), dp(150f * s))
        else LinearLayout.LayoutParams(dp(84f * s), dp(230f * s))
        fv.onChange = { v -> setPct(curStream, v); rearm() }

        val mute = TextView(this)
        mute.textSize = 24f
        mute.setTextColor(Color.WHITE)
        mute.gravity = Gravity.CENTER
        mute.setPadding(pad, dp(6f), pad, dp(2f))
        mute.setOnClickListener { toggleMute() }

        val extra = LinearLayout(this)
        extra.orientation = LinearLayout.VERTICAL
        extra.visibility = if (expanded) View.VISIBLE else View.GONE
        extraBars.clear()
        for (i in streamIds.indices) {
            val id = streamIds[i]
            val l = TextView(this)
            l.text = streamNames[i]
            l.setTextColor(Color.WHITE)
            l.textSize = 11f
            val sb = SeekBar(this)
            sb.max = 100
            sb.layoutParams = LinearLayout.LayoutParams(dp(170f * s), ViewGroup.LayoutParams.WRAP_CONTENT)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(b: SeekBar?, p: Int, u: Boolean) {
                    if (u) { setPct(id, p); rearm() }
                }
                override fun onStartTrackingTouch(b: SeekBar?) { rearm() }
                override fun onStopTrackingTouch(b: SeekBar?) { rearm() }
            })
            extra.addView(l)
            extra.addView(sb)
            extraBars[id] = sb
        }

        dots.setOnClickListener {
            expanded = !expanded
            extra.visibility = if (expanded) View.VISIBLE else View.GONE
            rearm()
        }

        box.addView(dots)
        box.addView(name)
        box.addView(fv)
        box.addView(mute)
        box.addView(extra)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = (if (Fx.panelRight) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL
        lp.x = dp(10f)
        try {
            wm.addView(box, lp)
            panel = box
            flexV = fv
            title = name
            muteBtn = mute
        } catch (t: Throwable) {
            panel = null
        }
    }

    fun hide() {
        handler.removeCallbacks(hideRun)
        panel?.let {
            try { wm.removeView(it) } catch (t: Throwable) {}
        }
        panel = null
        flexV = null
        title = null
        muteBtn = null
        extraBars.clear()
    }

    override fun onDestroy() {
        hide()
        instance = null
        super.onDestroy()
    }
}
