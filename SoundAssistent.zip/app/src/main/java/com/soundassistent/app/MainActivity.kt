package com.soundassistent.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var am: AudioManager
    private lateinit var flex: FlexVolumeView
    private lateinit var status: TextView
    private lateinit var presetSpinner: Spinner
    private val sliders = ArrayList<VSlider>()
    private val labels = ArrayList<TextView>()
    private var stream = AudioManager.STREAM_MUSIC
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() { syncVolume(); handler.postDelayed(this, 500) }
    }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val streamNames = arrayOf("Medien", "Klingelton", "Alarm", "Benachrichtigung", "Anruf")
    private val streamIds = intArrayOf(
        AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING, AudioManager.STREAM_ALARM,
        AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_VOICE_CALL
    )
    private val presetNames = arrayOf("Eigene", "Flach", "Bass", "Höhen", "Stimme", "Rock", "Pop")
    private val presets = arrayOf(
        null,
        intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0),
        intArrayOf(6, 5, 4, 2, 0, 0, 0, 0, 0),
        intArrayOf(0, 0, 0, 0, 0, 2, 4, 6, 6),
        intArrayOf(-2, -1, 0, 2, 4, 4, 2, 0, -1),
        intArrayOf(5, 3, -1, -3, -1, 2, 4, 5, 5),
        intArrayOf(-1, 2, 4, 4, 2, 0, -1, -1, -1)
    )

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun tv(s: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
        text = s
        setTextColor(Color.WHITE)
        textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(0xFF2B2B2B.toInt())
                cornerRadius = dp(24).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
        }
        c.addView(tv(title, 20f, true))
        return c
    }

    private fun btn(label: String, f: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        setOnClickListener { f() }
    }

    private fun sw(label: String, on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
        text = label
        setTextColor(Color.WHITE)
        isChecked = on
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, c -> f(c) }
    }

    private fun seek(card: LinearLayout, label: String, maxV: Int, init: Int,
                     fmt: (Int) -> String, f: (Int) -> Unit) {
        val t = tv(label + ": " + fmt(init), 15f)
        t.setPadding(0, dp(10), 0, 0)
        val s = SeekBar(this)
        s.max = maxV
        s.progress = init
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                t.text = label + ": " + fmt(p)
                f(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        card.addView(t)
        card.addView(s)
    }

    private fun radios(card: LinearLayout, title: String, opts: Array<String>, sel: Int, f: (Int) -> Unit) {
        val t = tv(title, 15f)
        t.setPadding(0, dp(10), 0, 0)
        card.addView(t)
        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.HORIZONTAL
        for (o in opts) {
            val rb = RadioButton(this)
            rb.text = o
            rb.setTextColor(Color.WHITE)
            rb.id = View.generateViewId()
            rg.addView(rb)
        }
        (rg.getChildAt(sel) as RadioButton).isChecked = true
        rg.setOnCheckedChangeListener { g, id -> f(g.indexOfChild(g.findViewById(id))) }
        card.addView(rg)
    }

    private fun changed() {
        Fx.save(this)
        Fx.apply()
        refreshStatus()
    }

    private fun refreshStatus() {
        val sb = StringBuilder()
        for ((k, v) in Fx.status) sb.append(if (v) "✓ " else "✗ ").append(k).append(" (").append(if (v) "verfügbar" else "nicht verfügbar auf diesem Gerät").append(")\n")
        sb.append("\nHinweis: Effekte wirken nur, wenn die Musik-App sie zulässt.")
        status.text = sb.toString()
    }

    private fun syncVolume() {
        if (flex.touching) return
        val max = am.getStreamMaxVolume(stream)
        flex.value = if (max > 0) am.getStreamVolume(stream) * 100 / max else 0
    }

    private fun setVolPercent(p: Int) {
        val max = am.getStreamMaxVolume(stream)
        try {
            am.setStreamVolume(stream, Math.round(p * max / 100f), 0)
        } catch (e: SecurityException) {
            Toast.makeText(this, "Nicht erlaubt (Nicht stören aktiv?)", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        Fx.load(this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        try { startForegroundService(Intent(this, FxService::class.java)) } catch (t: Throwable) {}
        Fx.apply()
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(40), dp(16), dp(40))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.addView(root)
        setContentView(scroll)

        root.addView(tv("Sound Assistent", 28f, true))

        // ---- Lautstärke ----
        val vc = card("Lautstärke")
        val streamSpinner = Spinner(this)
        streamSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, streamNames)
        streamSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                stream = streamIds[pos]
                syncVolume()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        vc.addView(streamSpinner)
        flex = FlexVolumeView(this)
        flex.layoutParams = LinearLayout.LayoutParams(MATCH, dp(280))
        flex.knob = Fx.knob
        flex.lighting = Fx.lighting
        flex.texture = Fx.texture
        flex.onChange = { v -> setVolPercent(v) }
        vc.addView(flex)
        val vr = LinearLayout(this)
        vr.orientation = LinearLayout.HORIZONTAL
        vr.addView(btn("Stumm") { setVolPercent(0); flex.value = 0 })
        vr.addView(btn("−") { am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, 0); syncVolume() })
        vr.addView(btn("+") { am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, 0); syncVolume() })
        vr.addView(btn("Max") { setVolPercent(100); flex.value = 100 })
        vc.addView(vr)
        root.addView(vc)

        // ---- Equalizer ----
        val ec = card("Equalizer")
        ec.addView(sw("Equalizer an", Fx.eqOn) { Fx.eqOn = it; changed() })
        presetSpinner = Spinner(this)
        presetSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presetNames)
        presetSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val pr = presets[pos] ?: return
                for (i in 0..8) {
                    Fx.gains[i] = pr[i]
                    sliders[i].value = pr[i]
                    labels[i].text = pr[i].toString()
                }
                changed()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        ec.addView(presetSpinner)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in 0..8) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            val vl = tv(Fx.gains[i].toString(), 11f)
            vl.gravity = Gravity.CENTER
            val s = VSlider(this)
            s.value = Fx.gains[i]
            s.layoutParams = LinearLayout.LayoutParams(MATCH, dp(220))
            s.onChange = { v ->
                Fx.gains[i] = v
                vl.text = v.toString()
                presetSpinner.setSelection(0)
                changed()
            }
            val hz = Fx.freqs[i]
            val lb = tv(if (hz >= 1000) (hz / 1000).toString() + "k" else hz.toString(), 12f)
            lb.gravity = Gravity.CENTER
            col.addView(vl)
            col.addView(s)
            col.addView(lb)
            sliders.add(s)
            labels.add(vl)
            row.addView(col)
        }
        ec.addView(row)
        val rr = LinearLayout(this)
        rr.orientation = LinearLayout.HORIZONTAL
        rr.addView(btn("Zurücksetzen") { presetSpinner.setSelection(1) })
        ec.addView(rr)
        root.addView(ec)

        // ---- Effekte ----
        val fc = card("Klang-Effekte")
        fc.addView(sw("UHQ upscaler (hellere Höhen)", Fx.uhq) { Fx.uhq = it; changed() })
        fc.addView(sw("Concert hall", Fx.concert) { Fx.concert = it; changed() })
        fc.addView(sw("Dolby Atmos (Raumklang-Ersatz)", Fx.atmos) { Fx.atmos = it; changed() })
        seek(fc, "Bass-Boost", 100, Fx.bass, { it.toString() + " %" }) { Fx.bass = it; changed() }
        seek(fc, "Lautstärke-Verstärker", 10, Fx.loud, { it.toString() + " dB" }) { Fx.loud = it; changed() }
        fc.addView(tv("Achtung: hohe Verstärkung kann Lautsprecher und Gehör schädigen.", 12f))
        root.addView(fc)

        // ---- Flex Volume UI ----
        val uc = card("Flex Volume UI")
        radios(uc, "Lighting Effect", arrayOf("Hell", "Dämmerung"), Fx.lighting) {
            Fx.lighting = it; flex.lighting = it; changed()
        }
        radios(uc, "Texture", arrayOf("Mesh", "Aurora"), Fx.texture) {
            Fx.texture = it; flex.texture = it; changed()
        }
        radios(uc, "Control Type", arrayOf("Bar", "Knob"), if (Fx.knob) 1 else 0) {
            Fx.knob = (it == 1); flex.knob = Fx.knob; changed()
        }
        root.addView(uc)

        // ---- Status ----
        val sc = card("Status")
        status = tv("", 14f)
        sc.addView(status)
        root.addView(sc)
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        handler.post(poll)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        super.onPause()
    }
}
