package com.soundassistent.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var am: AudioManager
    private lateinit var flex: FlexVolumeView
    private lateinit var status: TextView
    private lateinit var presetSpinner: Spinner
    private val sliders = ArrayList<VSlider>()
    private val labels = ArrayList<TextView>()
    private val streamBars = ArrayList<SeekBar>()
    private var stream = AudioManager.STREAM_MUSIC
    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() { syncVolume(); handler.postDelayed(this, 500) }
    }
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val streamNames = arrayOf("Medien", "Klingelton", "Alarm", "Benachrichtigung", "Anruf")
    private val streamIds = intArrayOf(
        AudioManager.STREAM_MUSIC, AudioManager.STREAM_RING, AudioManager.STREAM_ALARM,
        AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_VOICE_CALL
    )
    private val presetNames = arrayOf("Eigene", "Flach", "Bass", "Höhen", "Stimme", "Rock", "Pop")
    private val presets = arrayOf(
        null,
        intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0),
        intArrayOf(6, 5, 4, 2, 0, 0, 0, 0, 0),
        intArrayOf(0, 0, 0, 0, 0, 2, 4, 6, 6),
        intArrayOf(-2, -1, 0, 2, 4, 4, 2, 0, -1),
        intArrayOf(5, 3, -1, -3, -1, 2, 4, 5, 5),
        intArrayOf(-1, 2, 4, 4, 2, 0, -1, -1, -1)
    )

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun tv(s: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
        text = s
        setTextColor(Color.WHITE)
        textSize = size
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(0xFF2B2B2B.toInt())
                cornerRadius = dp(24).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(14) }
        }
        c.addView(tv(title, 20f, true))
        return c
    }

    private fun btn(label: String, f: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        setOnClickListener { f() }
    }

    private fun rowOf(vararg v: View): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        for (x in v) r.addView(x)
        return r
    }

    private fun sw(label: String, on: Boolean, f: (Boolean) -> Unit) = Switch(this).apply {
        text = label
        setTextColor(Color.WHITE)
        isChecked = on
        setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, c -> f(c) }
    }

    private fun seek(card: LinearLayout, label: String, maxV: Int, init: Int,
                     fmt: (Int) -> String, f: (Int) -> Unit) {
        val t = tv(label + ": " + fmt(init), 15f)
        t.setPadding(0, dp(10), 0, 0)
        val s = SeekBar(this)
        s.max = maxV
        s.progress = init
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) {
                t.text = label + ": " + fmt(p)
                f(p)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        card.addView(t)
        card.addView(s)
    }

    private fun radios(card: LinearLayout, title: String, opts: Array<String>, sel: Int, f: (Int) -> Unit) {
        val t = tv(title, 15f)
        t.setPadding(0, dp(10), 0, 0)
        card.addView(t)
        val rg = RadioGroup(this)
        rg.orientation = RadioGroup.HORIZONTAL
        for (o in opts) {
            val rb = RadioButton(this)
            rb.text = o
            rb.setTextColor(Color.WHITE)
            rb.id = View.generateViewId()
            rg.addView(rb)
        }
        (rg.getChildAt(sel) as RadioButton).isChecked = true
        rg.setOnCheckedChangeListener { g, id -> f(g.indexOfChild(g.findViewById(id))) }
        card.addView(rg)
    }

    private fun changed() {
        Fx.save(this)
        Fx.apply()
        refreshStatus()
    }

    private fun outputName(): String {
        var r = "Lautsprecher"
        try {
            for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
                when (d.type) {
                    AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> return "Bluetooth"
                    AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> r = "Kopfhörer (Kabel)"
                    AudioDeviceInfo.TYPE_USB_HEADSET -> r = "USB-Kopfhörer"
                }
            }
        } catch (t: Throwable) {}
        return r
    }

    private fun refreshStatus() {
        if (!::status.isInitialized) return
        val sb = StringBuilder()
        sb.append("Ausgabe: ").append(outputName()).append("\n")
        sb.append(if (SoundPanelService.instance != null) "✓ " else "✗ ")
            .append("Eigene Lautstärke-Leiste (Bedienungshilfe ")
            .append(if (SoundPanelService.instance != null) "aktiv)\n" else "noch aus)\n")
        for ((k, v) in Fx.status) {
            sb.append(if (v) "✓ " else "✗ ").append(k)
                .append(if (v) "\n" else " (auf diesem Gerät nicht verfügbar)\n")
        }
        sb.append("\nHinweis: Effekte wirken nur, wenn die Musik-App sie zulässt.")
        status.text = sb.toString()
    }

    private fun getPct(id: Int): Int {
        val m = am.getStreamMaxVolume(id)
        return if (m > 0) am.getStreamVolume(id) * 100 / m else 0
    }

    private fun setPct(id: Int, p: Int) {
        try {
            val max = am.getStreamMaxVolume(id)
            am.setStreamVolume(id, Math.round(p * max / 100f), 0)
            if (id == AudioManager.STREAM_MUSIC) Fx.enforceLimit(this)
        } catch (e: SecurityException) {
            toast("Nicht erlaubt (Nicht stören aktiv?)")
        }
    }

    private fun syncVolume() {
        if (!::flex.isInitialized) return
        if (!flex.touching) flex.value = getPct(stream)
        for (i in streamBars.indices) {
            if (!streamBars[i].isPressed) streamBars[i].progress = getPct(streamIds[i])
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        Fx.load(this)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        try { startForegroundService(Intent(this, FxService::class.java)) } catch (t: Throwable) {}
        Fx.apply()
        buildUi()
    }

    // ---------- Profile ----------
    private fun profiles(): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        val raw = getSharedPreferences("fx", Context.MODE_PRIVATE).getString("profiles", "") ?: ""
        for (line in raw.split("\n")) {
            val i = line.indexOf('=')
            if (i > 0) m[line.substring(0, i)] = line.substring(i + 1)
        }
        return m
    }

    private fun saveProfiles(m: Map<String, String>) {
        val s = m.entries.joinToString("\n") { it.key + "=" + it.value }
        getSharedPreferences("fx", Context.MODE_PRIVATE).edit().putString("profiles", s).apply()
    }

    private fun profileSave() {
        val et = EditText(this)
        et.hint = "Profilname"
        AlertDialog.Builder(this)
            .setTitle("Profil speichern")
            .setView(et)
            .setPositiveButton("Speichern") { _, _ ->
                val n = et.text.toString().replace("=", "").replace("\n", " ").trim()
                if (n.isNotEmpty()) {
                    val m = profiles()
                    m[n] = Fx.profileString()
                    saveProfiles(m)
                    toast("Profil „" + n + "“ gespeichert")
                }
            }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun profileLoad() {
        val m = profiles()
        if (m.isEmpty()) { toast("Noch keine Profile gespeichert"); return }
        val names = m.keys.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Profil laden")
            .setItems(names) { _, which ->
                val s = m[names[which]] ?: ""
                if (Fx.applyProfile(s)) {
                    Fx.save(this)
                    Fx.apply()
                    buildUi()
                }
            }
            .show()
    }

    private fun profileDelete() {
        val m = profiles()
        if (m.isEmpty()) { toast("Keine Profile vorhanden"); return }
        val names = m.keys.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Profil löschen")
            .setItems(names) { _, which ->
                m.remove(names[which])
                saveProfiles(m)
                toast("Gelöscht")
            }
            .show()
    }

    private fun buildUi() {
        sliders.clear()
        labels.clear()
        streamBars.clear()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(40), dp(16), dp(40))
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.BLACK)
        scroll.addView(root)
        setContentView(scroll)

        // ---- Kopf mit Logo ----
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_logo)
        val lpLogo = LinearLayout.LayoutParams(dp(64), dp(64))
        lpLogo.rightMargin = dp(14)
        logo.layoutParams = lpLogo
        head.addView(logo)
        head.addView(tv("Sound Assistent", 28f, true))
        root.addView(head)

        // ---- Lautstärke ----
        val vc = card("Lautstärke")
        val streamSpinner = Spinner(this)
        streamSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, streamNames)
        streamSpinner.setSelection(streamIds.indexOf(stream))
        streamSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                stream = streamIds[pos]
                syncVolume()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        vc.addView(streamSpinner)
        flex = FlexVolumeView(this)
        flex.layoutParams = LinearLayout.LayoutParams(MATCH, dp(280))
        flex.knob = Fx.knob
        flex.lighting = Fx.lighting
        flex.texture = Fx.texture
        flex.onChange = { v -> setPct(stream, v) }
        vc.addView(flex)
        vc.addView(rowOf(
            btn("Stumm") { setPct(stream, 0); flex.value = 0 },
            btn("−") { am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, 0); syncVolume() },
            btn("+") { am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, 0); syncVolume() },
            btn("Max") { setPct(stream, 100); flex.value = 100 }
        ))
        root.addView(vc)

        // ---- Alle Lautstärken ----
        val ac = card("Alle Lautstärken")
        for (i in streamIds.indices) {
            val id = streamIds[i]
            val l = tv(streamNames[i], 14f)
            l.setPadding(0, dp(8), 0, 0)
            ac.addView(l)
            val sb = SeekBar(this)
            sb.max = 100
            sb.progress = getPct(id)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) setPct(id, p) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            streamBars.add(sb)
            ac.addView(sb)
        }
        root.addView(ac)

        // ---- Eigene Lautstärke-Leiste ----
        val pc = card("Eigene Lautstärke-Leiste")
        pc.addView(tv("Ersetzt beim Drücken der Lautstärketasten die System-Leiste (wie Sound Assistent von Good Lock). Dafür muss die Bedienungshilfe „Sound Assistent Lautstärke-Leiste“ eingeschaltet sein.", 13f))
        pc.addView(sw("Eigene Leiste verwenden", Fx.panelOn) { Fx.panelOn = it; changed() })
        pc.addView(rowOf(
            btn("Bedienungshilfe öffnen") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
            btn("Leiste testen") {
                val s = SoundPanelService.instance
                if (s != null) s.show(AudioManager.STREAM_MUSIC)
                else toast("Bedienungshilfe ist noch nicht eingeschaltet")
            }
        ))
        radios(pc, "Position", arrayOf("Links", "Rechts"), if (Fx.panelRight) 1 else 0) { Fx.panelRight = (it == 1); changed() }
        radios(pc, "Größe", arrayOf("Klein", "Mittel", "Groß"), Fx.panelSize) { Fx.panelSize = it; changed() }
        radios(pc, "Tasten steuern", arrayOf("Immer Medien", "Automatisch"), if (Fx.keyAuto) 1 else 0) { Fx.keyAuto = (it == 1); changed() }
        seek(pc, "Anzeigedauer", 5, Fx.timeout - 1, { (it + 1).toString() + " s" }) { Fx.timeout = it + 1; changed() }
        seek(pc, "Deckkraft", 80, Fx.opacity - 20, { (it + 20).toString() + " %" }) { Fx.opacity = it + 20; changed() }
        pc.addView(sw("Vibration bei Tastendruck", Fx.haptic) { Fx.haptic = it; changed() })
        root.addView(pc)

        // ---- Equalizer ----
        val ec = card("Equalizer")
        ec.addView(sw("Equalizer an", Fx.eqOn) { Fx.eqOn = it; changed() })
        presetSpinner = Spinner(this)
        presetSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, presetNames)
        presetSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val pr = presets[pos] ?: return
                for (i in 0..8) {
                    Fx.gains[i] = pr[i]
                    sliders[i].value = pr[i]
                    labels[i].text = pr[i].toString()
                }
                changed()
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        ec.addView(presetSpinner)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        for (i in 0..8) {
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.gravity = Gravity.CENTER_HORIZONTAL
            col.layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
            val vl = tv(Fx.gains[i].toString(), 11f)
            vl.gravity = Gravity.CENTER
            val s = VSlider(this)
            s.value = Fx.gains[i]
            s.layoutParams = LinearLayout.LayoutParams(MATCH, dp(220))
            s.onChange = { v ->
                Fx.gains[i] = v
                vl.text = v.toString()
                presetSpinner.setSelection(0)
                changed()
            }
            val hz = Fx.freqs[i]
            val lb = tv(if (hz >= 1000) (hz / 1000).toString() + "k" else hz.toString(), 12f)
            lb.gravity = Gravity.CENTER
            col.addView(vl)
            col.addView(s)
            col.addView(lb)
            sliders.add(s)
            labels.add(vl)
            row.addView(col)
        }
        ec.addView(row)
        ec.addView(rowOf(btn("Zurücksetzen") { presetSpinner.setSelection(1) }))
        root.addView(ec)

        // ---- Effekte ----
        val fc = card("Klang-Effekte")
        fc.addView(sw("UHQ upscaler (hellere Höhen)", Fx.uhq) { Fx.uhq = it; changed() })
        fc.addView(sw("Concert hall", Fx.concert) { Fx.concert = it; changed() })
        fc.addView(sw("Dolby Atmos (Raumklang-Ersatz)", Fx.atmos) { Fx.atmos = it; changed() })
        seek(fc, "Bass-Boost", 100, Fx.bass, { it.toString() + " %" }) { Fx.bass = it; changed() }
        seek(fc, "Lautstärke-Verstärker", 10, Fx.loud, { it.toString() + " dB" }) { Fx.loud = it; changed() }
        fc.addView(tv("Achtung: hohe Verstärkung kann Lautsprecher und Gehör schädigen.", 12f))
        root.addView(fc)

        // ---- Profile ----
        val prc = card("Profile (Equalizer + Effekte)")
        prc.addView(rowOf(
            btn("Speichern") { profileSave() },
            btn("Laden") { profileLoad() },
            btn("Löschen") { profileDelete() }
        ))
        root.addView(prc)

        // ---- Flex Volume UI ----
        val uc = card("Flex Volume UI")
        radios(uc, "Lighting Effect", arrayOf("Hell", "Dämmerung"), Fx.lighting) {
            Fx.lighting = it; flex.lighting = it; changed()
        }
        radios(uc, "Texture", arrayOf("Mesh", "Aurora"), Fx.texture) {
            Fx.texture = it; flex.texture = it; changed()
        }
        radios(uc, "Control Type", arrayOf("Bar", "Knob"), if (Fx.knob) 1 else 0) {
            Fx.knob = (it == 1); flex.knob = Fx.knob; changed()
        }
        root.addView(uc)

        // ---- Begrenzer & Timer ----
        val lc = card("Begrenzer & Einschlaf-Timer")
        seek(lc, "Max. Medienlautstärke", 90, Fx.limit - 10, { (it + 10).toString() + " %" }) {
            Fx.limit = it + 10
            changed()
            Fx.enforceLimit(this)
        }
        var sleepMin = 30
        seek(lc, "Einschlaf-Timer", 115, 25, { (it + 5).toString() + " min" }) { sleepMin = it + 5 }
        lc.addView(rowOf(
            btn("Timer starten") { Fx.startSleep(sleepMin); toast("Timer läuft: " + sleepMin + " min") },
            btn("Timer stoppen") { Fx.cancelSleep(); toast("Timer gestoppt") }
        ))
        lc.addView(tv("Am Ende wird die Musik 30 Sekunden lang ausgeblendet und pausiert.", 12f))
        root.addView(lc)

        // ---- Balance & Mono ----
        val bc = card("Balance & Mono")
        val canWrite = Settings.System.canWrite(this)
        bc.addView(tv(if (canWrite) "Berechtigung „Systemeinstellungen ändern“ erteilt." else "Dafür wird die Berechtigung „Systemeinstellungen ändern“ benötigt.", 13f))
        bc.addView(rowOf(btn("Berechtigung erteilen") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + packageName)))
        }))
        val monoOn = try { Settings.System.getInt(contentResolver, "master_mono", 0) == 1 } catch (t: Throwable) { false }
        bc.addView(sw("Mono-Audio", monoOn) {
            if (Settings.System.canWrite(this)) {
                try { Settings.System.putInt(contentResolver, "master_mono", if (it) 1 else 0) } catch (t: Throwable) { toast("Nicht möglich") }
            } else toast("Erst Berechtigung erteilen")
        })
        val bal = try { Settings.System.getFloat(contentResolver, "master_balance", 0f) } catch (t: Throwable) { 0f }
        seek(bc, "Links/Rechts-Balance", 200, Math.round(bal * 100) + 100, { (it - 100).toString() }) {
            if (Settings.System.canWrite(this)) {
                try { Settings.System.putFloat(contentResolver, "master_balance", (it - 100) / 100f) } catch (t: Throwable) {}
            }
        }
        root.addView(bc)

        // ---- Status ----
        val sc = card("Status")
        status = tv("", 14f)
        sc.addView(status)
        root.addView(sc)
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        handler.post(poll)
    }

    override fun onPause() {
        handler.removeCallbacks(poll)
        super.onPause()
    }
}
