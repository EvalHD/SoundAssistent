package com.soundassistent.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.MotionEvent
import android.view.View

class VSlider(c: Context) : View(c) {
    var min = -10
    var max = 10
    var value = 0
        set(v) { field = v.coerceIn(min, max); invalidate() }
    var onChange: ((Int) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = c.resources.displayMetrics.density

    override fun onDraw(cv: Canvas) {
        val cx = width / 2f
        val top = 14f * d
        val bot = height - 14f * d
        val span = bot - top
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 4f * d
        p.color = 0x44FFFFFF
        cv.drawLine(cx, top, cx, bot, p)
        val y = bot - (value - min).toFloat() / (max - min) * span
        val zero = bot - (0 - min).toFloat() / (max - min) * span
        p.color = 0xFF26C6B0.toInt()
        cv.drawLine(cx, zero, cx, y, p)
        p.color = Color.WHITE
        cv.drawCircle(cx, y, 8f * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val top = 14f * d
        val bot = height - 14f * d
        val frac = 1f - (e.y - top) / (bot - top)
        val v = Math.round(min + frac * (max - min))
        value = v
        onChange?.invoke(value)
        return true
    }
}

class FlexVolumeView(c: Context) : View(c) {
    var value = 50
        set(v) { field = v.coerceIn(0, 100); invalidate() }
    var knob = true
        set(v) { field = v; invalidate() }
    var lighting = 0
        set(v) { field = v; invalidate() }
    var texture = 0
        set(v) { field = v; invalidate() }
    var touching = false
    var onChange: ((Int) -> Unit)? = null

    private val d = c.resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 34f * d
    }
    private val pal = arrayOf(
        intArrayOf(0xFFFF5A5A.toInt(), 0xFFFFE45A.toInt(), 0xFF5AFF8C.toInt(),
            0xFF5AC8FF.toInt(), 0xFFB05AFF.toInt(), 0xFFFF5A5A.toInt()),
        intArrayOf(0xFFB48CFF.toInt(), 0xFF6E8CFF.toInt(), 0xFF3C3C78.toInt(),
            0xFFFF6EC8.toInt(), 0xFF8CE6FF.toInt(), 0xFFB48CFF.toInt())
    )

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        var cols = pal[lighting.coerceIn(0, 1)]
        if (knob) {
            val r = Math.min(w, h) / 2f * 0.88f
            val cx = w / 2f
            val cy = h / 2f
            p.style = Paint.Style.FILL
            p.shader = SweepGradient(cx, cy, cols, null)
            cv.save()
            cv.rotate(if (texture == 0) 0f else 90f, cx, cy)
            cv.drawCircle(cx, cy, r, p)
            cv.restore()
            p.shader = RadialGradient(
                cx, cy, r,
                intArrayOf(0x33FFFFFF, 0x00FFFFFF, 0x66000000),
                floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP
            )
            cv.drawCircle(cx, cy, r, p)
            p.shader = null
            val ang = Math.toRadians(-135.0 + value * 2.7)
            val s = Math.sin(ang).toFloat()
            val co = Math.cos(ang).toFloat()
            p.color = Color.WHITE
            p.strokeWidth = 8f * d
            p.strokeCap = Paint.Cap.ROUND
            cv.drawLine(cx + s * r * 0.62f, cy - co * r * 0.62f, cx + s * r * 0.82f, cy - co * r * 0.82f, p)
            cv.drawText(value.toString(), cx, cy + 12f * d, tp)
        } else {
            if (texture == 1) cols = cols.reversedArray()
            val bw = Math.min(w * 0.5f, 140f * d)
            val l = (w - bw) / 2f
            val rect = RectF(l, 8f * d, l + bw, h - 8f * d)
            val path = Path()
            path.addRoundRect(rect, bw / 2f, bw / 2f, Path.Direction.CW)
            cv.save()
            cv.clipPath(path)
            p.style = Paint.Style.FILL
            p.shader = null
            p.color = 0xFF2A2A2A.toInt()
            cv.drawRect(rect, p)
            p.shader = LinearGradient(0f, rect.bottom, 0f, rect.top, cols, null, Shader.TileMode.CLAMP)
            val fillTop = rect.bottom - (rect.bottom - rect.top) * value / 100f
            cv.drawRect(rect.left, fillTop, rect.right, rect.bottom, p)
            p.shader = null
            cv.restore()
            cv.drawText(value.toString(), w / 2f, rect.top + 44f * d, tp)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> touching = true
            else -> touching = false
        }
        val v: Int
        if (knob) {
            val dx = e.x - width / 2f
            val dy = e.y - height / 2f
            var a = Math.toDegrees(Math.atan2(dx.toDouble(), (-dy).toDouble()))
            a = a.coerceIn(-135.0, 135.0)
            v = Math.round((a + 135.0) / 270.0 * 100.0).toInt()
        } else {
            val top = 8f * d
            val bot = height - 8f * d
            v = Math.round((1f - (e.y - top) / (bot - top)) * 100f)
        }
        value = v
        onChange?.invoke(value)
        return true
    }
}
