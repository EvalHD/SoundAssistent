package com.soundassistent.app

import android.content.Context
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.util.Log

object Fx {
    private const val TAG = "SoundAssistent"
    val freqs = intArrayOf(63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    val gains = IntArray(9)
    var eqOn = true
    var uhq = false
    var concert = false
    var atmos = false
    var bass = 0
    var loud = 0
    var lighting = 0
    var texture = 0
    var knob = true
    val status = LinkedHashMap<String, Boolean>()

    private var eq: Equalizer? = null
    private var rev: PresetReverb? = null
    private var virt: Virtualizer? = null
    private var bb: BassBoost? = null
    private var le: LoudnessEnhancer? = null
    private val failed = HashSet<String>()

    private fun <T> make(name: String, f: () -> T): T? {
        if (name in failed) return null
        return try { f() } catch (t: Throwable) { failed.add(name); Log.e(TAG, name, t); null }
    }

    fun gainAt(hz: Double): Double {
        if (hz <= freqs[0]) return gains[0].toDouble()
        if (hz >= freqs[8]) return gains[8].toDouble()
        for (i in 0 until 8) {
            if (hz < freqs[i + 1]) {
                val a = Math.log(freqs[i].toDouble())
                val b = Math.log(freqs[i + 1].toDouble())
                val t = (Math.log(hz) - a) / (b - a)
                return gains[i] + t * (gains[i + 1] - gains[i])
            }
        }
        return 0.0
    }

    @Synchronized
    fun apply() {
        if (eq == null) eq = make("Equalizer") { Equalizer(0, 0) }
        eq?.let { e ->
            try {
                e.setEnabled(eqOn)
                val r = e.bandLevelRange
                for (b in 0 until e.numberOfBands.toInt()) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000.0
                    var g = gainAt(hz)
                    if (uhq && hz >= 6000) g += 2.0
                    val mb = (g * 100).toInt().coerceIn(r[0].toInt(), r[1].toInt())
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
            } catch (t: Throwable) { Log.e(TAG, "eq", t) }
        }

        if (rev == null) rev = make("Concert Hall") { PresetReverb(0, 0) }
        rev?.let {
            try {
                it.setPreset(PresetReverb.PRESET_LARGEHALL)
                it.setEnabled(concert)
            } catch (t: Throwable) { Log.e(TAG, "rev", t) }
        }

        if (virt == null) virt = make("Raumklang (Atmos-Ersatz)") { Virtualizer(0, 0) }
        virt?.let {
            try {
                if (it.strengthSupported) it.setStrength((if (atmos) 1000 else 0).toShort())
                it.setEnabled(atmos)
            } catch (t: Throwable) { Log.e(TAG, "virt", t) }
        }

        if (bb == null) bb = make("Bass-Boost") { BassBoost(0, 0) }
        bb?.let {
            try {
                if (it.strengthSupported) it.setStrength((bass * 10).toShort())
                it.setEnabled(bass > 0)
            } catch (t: Throwable) { Log.e(TAG, "bass", t) }
        }

        if (le == null) le = make("Lautstärke-Verstärker") { LoudnessEnhancer(0) }
        le?.let {
            try {
                it.setTargetGain(loud * 100)
                it.setEnabled(loud > 0)
            } catch (t: Throwable) { Log.e(TAG, "loud", t) }
        }

        status["Equalizer"] = eq != null
        status["Concert Hall"] = rev != null
        status["Raumklang (Atmos-Ersatz)"] = virt != null
        status["Bass-Boost"] = bb != null
        status["Lautstärke-Verstärker"] = le != null
    }

    @Synchronized
    fun release() {
        try { eq?.release() } catch (_: Throwable) {}
        try { rev?.release() } catch (_: Throwable) {}
        try { virt?.release() } catch (_: Throwable) {}
        try { bb?.release() } catch (_: Throwable) {}
        try { le?.release() } catch (_: Throwable) {}
        eq = null; rev = null; virt = null; bb = null; le = null
    }

    fun load(c: Context) {
        val p = c.getSharedPreferences("fx", Context.MODE_PRIVATE)
        val g = (p.getString("gains", "") ?: "").split(",")
        for (i in 0..8) gains[i] = g.getOrNull(i)?.toIntOrNull() ?: 0
        eqOn = p.getBoolean("eqOn", true)
        uhq = p.getBoolean("uhq", false)
        concert = p.getBoolean("concert", false)
        atmos = p.getBoolean("atmos", false)
        bass = p.getInt("bass", 0)
        loud = p.getInt("loud", 0)
        lighting = p.getInt("lighting", 0)
        texture = p.getInt("texture", 0)
        knob = p.getBoolean("knob", true)
    }

    fun save(c: Context) {
        c.getSharedPreferences("fx", Context.MODE_PRIVATE).edit()
            .putString("gains", gains.joinToString(","))
            .putBoolean("eqOn", eqOn).putBoolean("uhq", uhq)
            .putBoolean("concert", concert).putBoolean("atmos", atmos)
            .putInt("bass", bass).putInt("loud", loud)
            .putInt("lighting", lighting).putInt("texture", texture)
            .putBoolean("knob", knob)
            .apply()
    }
}
