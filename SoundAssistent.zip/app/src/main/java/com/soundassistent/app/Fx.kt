package com.soundassistent.app

import android.content.Context
import android.media.AudioManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.PresetReverb
import android.media.audiofx.Virtualizer
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.KeyEvent

object Fx {
    private const val TAG = "SoundAssistent"
    val freqs = intArrayOf(63, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)
    val gains = IntArray(9)
    var eqOn = true
    var uhq = false
    var concert = false
    var atmos = false
    var bass = 0
    var loud = 0
    var lighting = 0
    var texture = 0
    var knob = true
    // Lautstärke-Leiste
    var panelOn = true
    var panelRight = true
    var panelSize = 1
    var keyAuto = false
    var timeout = 3
    var opacity = 85
    var haptic = true
    var limit = 100
    val status = LinkedHashMap<String, Boolean>()

    private var app: Context? = null
    private var eq: Equalizer? = null
    private var rev: PresetReverb? = null
    private var virt: Virtualizer? = null
    private var bb: BassBoost? = null
    private var le: LoudnessEnhancer? = null
    private val failed = HashSet<String>()

    private fun <T> make(name: String, f: () -> T): T? {
        if (name in failed) return null
        return try { f() } catch (t: Throwable) { failed.add(name); Log.e(TAG, name, t); null }
    }

    fun gainAt(hz: Double): Double {
        if (hz <= freqs[0]) return gains[0].toDouble()
        if (hz >= freqs[8]) return gains[8].toDouble()
        for (i in 0 until 8) {
            if (hz < freqs[i + 1]) {
                val a = Math.log(freqs[i].toDouble())
                val b = Math.log(freqs[i + 1].toDouble())
                val t = (Math.log(hz) - a) / (b - a)
                return gains[i] + t * (gains[i + 1] - gains[i])
            }
        }
        return 0.0
    }

    @Synchronized
    fun apply() {
        if (eq == null) eq = make("Equalizer") { Equalizer(0, 0) }
        eq?.let { e ->
            try {
                e.setEnabled(eqOn)
                val r = e.bandLevelRange
                for (b in 0 until e.numberOfBands.toInt()) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000.0
                    var g = gainAt(hz)
                    if (uhq && hz >= 6000) g += 2.0
                    val mb = (g * 100).toInt().coerceIn(r[0].toInt(), r[1].toInt())
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
            } catch (t: Throwable) { Log.e(TAG, "eq", t) }
        }

        if (rev == null) rev = make("Concert Hall") { PresetReverb(0, 0) }
        rev?.let {
            try {
                it.setPreset(PresetReverb.PRESET_LARGEHALL)
                it.setEnabled(concert)
            } catch (t: Throwable) { Log.e(TAG, "rev", t) }
        }

        if (virt == null) virt = make("Raumklang (Atmos-Ersatz)") { Virtualizer(0, 0) }
        virt?.let {
            try {
                if (it.strengthSupported) it.setStrength((if (atmos) 1000 else 0).toShort())
                it.setEnabled(atmos)
            } catch (t: Throwable) { Log.e(TAG, "virt", t) }
        }

        if (bb == null) bb = make("Bass-Boost") { BassBoost(0, 0) }
        bb?.let {
            try {
                if (it.strengthSupported) it.setStrength((bass * 10).toShort())
                it.setEnabled(bass > 0)
            } catch (t: Throwable) { Log.e(TAG, "bass", t) }
        }

        if (le == null) le = make("Lautstärke-Verstärker") { LoudnessEnhancer(0) }
        le?.let {
            try {
                it.setTargetGain(loud * 100)
                it.setEnabled(loud > 0)
            } catch (t: Throwable) { Log.e(TAG, "loud", t) }
        }

        status["Equalizer"] = eq != null
        status["Concert Hall"] = rev != null
        status["Raumklang (Atmos-Ersatz)"] = virt != null
        status["Bass-Boost"] = bb != null
        status["Lautstärke-Verstärker"] = le != null
    }

    @Synchronized
    fun release() {
        try { eq?.release() } catch (_: Throwable) {}
        try { rev?.release() } catch (_: Throwable) {}
        try { virt?.release() } catch (_: Throwable) {}
        try { bb?.release() } catch (_: Throwable) {}
        try { le?.release() } catch (_: Throwable) {}
        eq = null; rev = null; virt = null; bb = null; le = null
    }

    fun enforceLimit(c: Context) {
        if (limit >= 100) return
        try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val lim = Math.round(limit * max / 100f)
            if (am.getStreamVolume(AudioManager.STREAM_MUSIC) > lim) {
                am.setStreamVolume(AudioManager.STREAM_MUSIC, lim, 0)
            }
        } catch (t: Throwable) { Log.e(TAG, "limit", t) }
    }

    // ---------- Einschlaf-Timer ----------
    private val h = Handler(Looper.getMainLooper())
    var sleepEnd = 0L
    private var fadeFrom = -1

    private val tick = object : Runnable {
        override fun run() {
            val c = app ?: return
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val left = sleepEnd - System.currentTimeMillis()
            if (left <= 0) {
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE))
                val back = fadeFrom
                sleepEnd = 0L
                fadeFrom = -1
                if (back > 0) {
                    h.postDelayed({
                        try { am.setStreamVolume(AudioManager.STREAM_MUSIC, back, 0) } catch (_: Throwable) {}
                    }, 1500)
                }
                return
            }
            if (left <= 30000) {
                if (fadeFrom < 0) fadeFrom = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                try {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(fadeFrom * left / 30000f), 0)
                } catch (_: Throwable) {}
            }
            h.postDelayed(this, 1000)
        }
    }

    fun startSleep(min: Int) {
        cancelSleep()
        sleepEnd = System.currentTimeMillis() + min * 60000L
        fadeFrom = -1
        h.post(tick)
    }

    fun cancelSleep() {
        h.removeCallbacks(tick)
        val c = app
        if (c != null && fadeFrom > 0 && sleepEnd != 0L) {
            try {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.setStreamVolume(AudioManager.STREAM_MUSIC, fadeFrom, 0)
            } catch (_: Throwable) {}
        }
        sleepEnd = 0L
        fadeFrom = -1
    }

    // ---------- Speichern / Laden ----------
    fun load(c: Context) {
        app = c.applicationContext
        val p = c.getSharedPreferences("fx", Context.MODE_PRIVATE)
        val g = (p.getString("gains", "") ?: "").split(",")
        for (i in 0..8) gains[i] = g.getOrNull(i)?.toIntOrNull() ?: 0
        eqOn = p.getBoolean("eqOn", true)
        uhq = p.getBoolean("uhq", false)
        concert = p.getBoolean("concert", false)
        atmos = p.getBoolean("atmos", false)
        bass = p.getInt("bass", 0)
        loud = p.getInt("loud", 0)
        lighting = p.getInt("lighting", 0)
        texture = p.getInt("texture", 0)
        knob = p.getBoolean("knob", true)
        panelOn = p.getBoolean("panelOn", true)
        panelRight = p.getBoolean("panelRight", true)
        panelSize = p.getInt("panelSize", 1)
        keyAuto = p.getBoolean("keyAuto", false)
        timeout = p.getInt("timeout", 3)
        opacity = p.getInt("opacity", 85)
        haptic = p.getBoolean("haptic", true)
        limit = p.getInt("limit", 100)
    }

    fun save(c: Context) {
        c.getSharedPreferences("fx", Context.MODE_PRIVATE).edit()
            .putString("gains", gains.joinToString(","))
            .putBoolean("eqOn", eqOn).putBoolean("uhq", uhq)
            .putBoolean("concert", concert).putBoolean("atmos", atmos)
            .putInt("bass", bass).putInt("loud", loud)
            .putInt("lighting", lighting).putInt("texture", texture)
            .putBoolean("knob", knob)
            .putBoolean("panelOn", panelOn).putBoolean("panelRight", panelRight)
            .putInt("panelSize", panelSize).putBoolean("keyAuto", keyAuto)
            .putInt("timeout", timeout).putInt("opacity", opacity)
            .putBoolean("haptic", haptic).putInt("limit", limit)
            .apply()
    }

    // Profil = EQ + Effekte als Text
    fun profileString(): String {
        val l = ArrayList<Int>()
        for (g in gains) l.add(g)
        l.add(if (eqOn) 1 else 0)
        l.add(if (uhq) 1 else 0)
        l.add(if (concert) 1 else 0)
        l.add(if (atmos) 1 else 0)
        l.add(bass)
        l.add(loud)
        return l.joinToString(",")
    }

    fun applyProfile(s: String): Boolean {
        val v = s.split(",").map { it.trim().toIntOrNull() ?: 0 }
        if (v.size < 15) return false
        for (i in 0..8) gains[i] = v[i].coerceIn(-10, 10)
        eqOn = v[9] == 1
        uhq = v[10] == 1
        concert = v[11] == 1
        atmos = v[12] == 1
        bass = v[13].coerceIn(0, 100)
        loud = v[14].coerceIn(0, 10)
        return true
    }
}
